package com.example.controllers;

import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;


public class MainController {
    @FXML
    private AnchorPane mainPane;

    @FXML
    public void initialize() {

    }
}