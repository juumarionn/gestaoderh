package com.example.controllers;

public class UsuarioController {
    
}
